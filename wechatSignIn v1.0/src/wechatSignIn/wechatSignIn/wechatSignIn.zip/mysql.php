<html>
<head>
<meta charset="utf-8">
<title>函数功能测试</title>
</head>
<body>
<div align="center">
	<font size="10px" color="blue">
		<strong>这是功能测试页</strong>
	</font>
</div>
<br/><br/><br/><br/>
<?php
$str=",1,2,3,4,5";
$array=explode(',',$str);
var_dump($array);
?>
</body>
</html>